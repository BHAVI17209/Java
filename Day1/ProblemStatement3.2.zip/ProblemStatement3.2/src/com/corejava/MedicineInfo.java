package com.corejava;

public class MedicineInfo {

	public void displayLabel() {
		System.out.println("Company :  Aurobindo Pharma Ltd");
		System.out.println("Address : Hyderabad, Telangana");
	}
}

class Tablet extends MedicineInfo {
	public void displayLabel() {
		System.out.println("store in a cool dry place");
	}
}

class Syrup extends MedicineInfo {
	public void displayLabel() {
		System.out.println("Consumption as directed by the doctor");
	}
}

class Ointment extends MedicineInfo {
	public void displayLabel() {
		System.out.println("for external use only");
	}
}
