package com.corejava;

import java.util.Scanner;

public class Strings {

	public static void main(String args[]) {
		String s,upper,rev = "";
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a string:");
		s = sc.nextLine();
		upper=s.toUpperCase();
		int length = s.length();
		System.out.println("String length :" + s.length());
		System.out.println("Upper case of given string: "+upper);

		for (int i = length - 1; i >= 0; i--)
			rev = rev + s.charAt(i);

		if (s.equals(rev))
			System.out.println(s + " is a palindrome");
		else
			System.out.println(s + " is not a palindrome");

	}

}
