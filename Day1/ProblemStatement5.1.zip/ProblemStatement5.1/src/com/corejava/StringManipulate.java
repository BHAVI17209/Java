package com.corejava;

public class StringManipulate {
	
	public static String acrnym(String phrase) {
		StringBuilder result= new StringBuilder();
		for(String token: phrase.split("\\s+"))// split at white space
			result.append(token.charAt(0));
		return result.toString();
		
	}

	public static void main(String[] args) {
		String s = "JAVA is Simple";
		System.out.println("Original String is: "+"\""+ s+"\"");
		StringBuilder k = new StringBuilder(s);
		
		String g = s.toUpperCase();
		System.out.println("\nString in uppercase: "+ g);
		System.out.println("\nString in lowercase: "+s.toLowerCase());
		System.out.println("\nAcronym of string is: "+ acrnym("Java is Simple"));
		
		// Swapping first and last word of string
		String words[]=s.split(" ");
		String temp=words[0];
		words[0]=words[words.length-1];
		words[words.length-1]=temp;
		s=String.join(" ", words);
		System.out.println("\nString after swapping: "+ s);
		
		System.out.println("\nReverse of string is: "+k.reverse());
		
		System.out.println("\nTotal length: "+k.length());
		
	}
}
