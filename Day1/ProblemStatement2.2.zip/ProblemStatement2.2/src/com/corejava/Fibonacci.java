package com.corejava;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {

		int cnt=13;// Problem statement is to print next 13 numbers in the sequence where each number is the sum of the previous two
		int num1, num2;
		//System.out.println("How may numbers you want in the sequence:");
		Scanner scanner = new Scanner(System.in);
		//count = scanner.nextInt();
		System.out.println("Enter the two number u want ");
		num1 = scanner.nextInt();
		num2 = scanner.nextInt();
		// scanner.close();
		System.out.print("Output series:  "+ num1+" "+num2+" ");

		int i = 1;
		while (i <= cnt) {
			//System.out.print(num1 + " ");
			int sumOfPrevTwo = num1 + num2;
			System.out.print(sumOfPrevTwo+" ");
			num1 = num2;
			num2 = sumOfPrevTwo;
			i++;
		}
	}

}
