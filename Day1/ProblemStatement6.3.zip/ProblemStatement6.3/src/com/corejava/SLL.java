package com.corejava;

import java.util.Vector;

public class SLL {
	public static void main(String[] args) {
		LinkedList<Employee> linkedList = new LinkedList<Employee>();
		// creation of Linked List

		linkedList.insertFirst(new Employee("41", "Bhavitha", "a1"));
		linkedList.insertFirst(new Employee("42", "Harry", "b1"));
		linkedList.insertFirst(new Employee("43", "Anu", "c1"));
		linkedList.insertFirst(new Employee("44", "Sandy", "d1"));
		linkedList.insertFirst(new Employee("45", "Jyo", "e1"));

		linkedList.displayLinkedList();
	}

}
