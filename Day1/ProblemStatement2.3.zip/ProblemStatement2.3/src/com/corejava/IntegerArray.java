package com.corejava;

import java.util.Arrays;

public class IntegerArray {

	public static void main(String[] args) {
		int arr[] = { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		System.out.println("Elements of the array are: " + Arrays.toString(arr));
		int sum = 0;
		int smallest = Integer.MAX_VALUE;
		for (int i = 0; i <= arr.length - 1; i++) {// sum of elements from index 0 to 14, here as elements after index
													// 14 are zeros,full array length has been considered
			sum += arr[i];

		}
		System.out.println("\nSum of the elements of the array from index 0 to 14 is: " + sum);
		arr[arr.length - 4] = sum;// Compute the sum of elements from index 0 to 14 and store it at element 15
									// i.e,element 15 is at index 14 so store at index 14
		System.out.println("Storing sum of elements from indx 0-14 is stored at 15th element: " + arr[arr.length - 4]);
		System.out.println("Elements of the array are: " + Arrays.toString(arr));
		double average = (sum / arr.length);
		System.out.println("\nAverage of an array is:" + average);
		arr[arr.length - 3] = (int) average;// Compute the average of all numbers and stores it at element 16, i.e., as
											// element 16 is in index 15 store average at index 15
		System.out.println("array inserting in 16th element is: " + arr[arr.length - 3]);
		System.out.println("Elements of the array are: " + Arrays.toString(arr));
		int index = 0;
		while (index < arr.length) {
			// check if smallest is greater than element
			if (smallest > arr[index]) {
				// update smallest
				smallest = arr[index];
			}
			index++;
		}
		System.out.println("\nThe smallest number is : " + smallest);
		System.out.println("array inserting in 17 element(i.e, at index 16) is: " + arr[arr.length - 2]);
		System.out.println("Elements of the array are: " + Arrays.toString(arr));
	}

}
