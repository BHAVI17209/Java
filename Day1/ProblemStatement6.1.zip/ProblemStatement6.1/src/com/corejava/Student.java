package com.corejava;

import java.util.ArrayList;

public class Student {

	public static void main(String[] args) {
		ArrayList<String> names = new ArrayList<String>();
		names.add("Bhavitha");
		names.add("reddy");
		names.add("harry");
		names.add("Nishvi");

		System.out.println("Name of the students: " + " " + names);

		System.out.println("Check student name exits or not: " + " " + names.contains("Bhavitha"));
	}

}
