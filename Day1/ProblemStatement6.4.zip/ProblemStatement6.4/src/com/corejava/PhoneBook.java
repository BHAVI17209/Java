package com.corejava;

import java.util.Scanner;

public class PhoneBook {
	public static String help_msg = "Press:   -  A  Add contact  -  S  Search  - Q  Exit :";

	public static void main(String[] args) {
		System.out.println("////*** Welcome to MyPhone Book ***////");
		Scanner s = new Scanner(System.in);
		for (;;) {
			System.out.print("Main Menu " + help_msg + "\n:");
			String command = s.nextLine().trim();

			if (command.equalsIgnoreCase("A")) {
				System.out.print("Type in contact details in the format: name,lastname,phone\n:");
			} else if (command.equalsIgnoreCase("S")) {
				System.out.print("Type the name you need for :\n:");

				Scanner scan = new Scanner(System.in);

			} else if (command.equalsIgnoreCase("Q")) {
				System.out.println("Bye User....");
				System.exit(0);
			} else {
				System.out.print("Unknown data pleace Try again :");
			}

		}

	}
}
