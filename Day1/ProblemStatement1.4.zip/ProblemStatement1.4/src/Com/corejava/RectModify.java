package Com.corejava;

import java.util.Scanner;

public class RectModify {
	
	private float length;
	private float width;
	private float area;
	private float perimeter;
	public float getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	
	public float getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public float getArea() {
		return area;
	}
	public void setArea(int area) {
		this.area = area;
	}
	public float getPerameter() {
		return perimeter;
	}
	public void setPerameter(int perameter) {
		this.perimeter = perameter;
	}
	
	public RectModify()
	{
		length=1;
		width=1;
	}
	void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter length of the rectangele: ");
		length = scan.nextInt();
		System.out.println("Enter width of the rectangel: ");
		width = scan.nextInt();
	}
	void areaRectangle() {
		area=length*width;
	}
	void perimeterRectangle() {
		perimeter = 2*(length+width);
	}
	void display() {
		if((length>0 && length<20)&&(width>0&& width<20)){
		System.out.println("Area of rectangle is: "+area);
		System.out.println("Perimeter of rectangle is : "+perimeter);
		}
	}
	public static void main(String[] args) {
		RectModify obj1=new RectModify();
		obj1.input();
		obj1.areaRectangle();
		obj1.perimeterRectangle();
		obj1.display();
		System.out.println("============================================");
		RectModify obj2=new RectModify();
		obj2.input();
		obj2.areaRectangle();
		obj2.perimeterRectangle();
		obj2.display();
		System.out.println("============================================");
		RectModify obj3=new RectModify();
		obj3.input();
		obj3.areaRectangle();
		obj3.perimeterRectangle();
		obj3.display();
		System.out.println("============================================");
		RectModify obj4=new RectModify();
		obj4.input();
		obj4.areaRectangle();
		obj4.perimeterRectangle();
		obj4.display();
		System.out.println("============================================");
		RectModify obj5=new RectModify();
		obj5.input();
		obj5.areaRectangle();
		obj5.perimeterRectangle();
		obj5.display();
		
	}

}
