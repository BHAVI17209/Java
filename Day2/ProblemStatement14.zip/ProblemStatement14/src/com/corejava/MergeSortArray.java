package com.corejava;

import java.util.Arrays;
import java.util.Scanner;

class MergeSortArray {

	// Function to merge array in sorted order
	public static void sortedMerge(int a[], int b[], int rest[], int n, int m) {
		// Sorting a[] and b[]
		Arrays.sort(a);
		Arrays.sort(b);

		// Merge two sorted arrays into rest[]
		int i = 0, j = 0, k = 0;
		while (i < n && j < m) {
			if (a[i] <= b[j]) {
				rest[k] = a[i];
				i += 1;
				k += 1;
			} else {
				rest[k] = b[j];
				j += 1;
				k += 1;
			}
		}

		while (i < n) { // Merging remaining
						// elements of a[] (if any)
			rest[k] = a[i];
			i += 1;
			k += 1;
		}
		while (j < m) { // Merging remaining
						// elements of b[] (if any)
			rest[k] = b[j];
			j += 1;
			k += 1;
		}
	}

	/* Driver program to test above function */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Length of an array: ");
		int[] a = new int[scan.nextInt()];
		System.out.println("Enter array Values: ");
		for (int i = 0; i < a.length; i++) {
			a[i] = scan.nextInt();
		}

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Length of an array: ");
		int[] b = new int[sc.nextInt()];
		System.out.println("Enter array Values: ");
		for (int i = 0; i < b.length; i++) {
			b[i] = scan.nextInt();
		}

		int n = a.length;
		int m = b.length;

		// Final merge list
		int rest[] = new int[n + m];
		sortedMerge(a, b, rest, n, m);

		System.out.print("Sorted merged list :");
		for (int i = 0; i < n + m; i++)
			System.out.print(" " + rest[i]);
	}
}