package com.corejava;

import java.util.Scanner;

public class ClimbingStairs {
	static int fib(int n) {
		if (n <= 1)
			return n;
		return fib(n - 1) + fib(n - 2);
	}

	static int climb(int s) {
		return fib(s + 1);
	}

	public static void main(String args[]) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Number of steps");
		int n = scan.nextInt();
		{
			System.out.println("Number of ways = " + climb(n));
		}
	}
}