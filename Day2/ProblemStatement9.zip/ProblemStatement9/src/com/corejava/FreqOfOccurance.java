package com.corejava;

import java.util.HashMap;
import java.util.Scanner;

public class FreqOfOccurance {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Length of an array: ");
		int[] arr = new int[scan.nextInt()];
		System.out.println("Enter array Values: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scan.nextInt();
		}
		HashMap<Integer, Integer> fre = solveIterative(arr);
		for (int value : fre.keySet()) {
			System.out.println(value + " occurs " + fre.get(value) + " times");
		}
	}

	public static HashMap<Integer, Integer> solveIterative(int[] arr) {
		HashMap<Integer, Integer> fre = new HashMap<Integer, Integer>();
		for (int value : arr) {
			if (!fre.containsKey(value)) {
				fre.put(value, 1);
			} else {
				fre.put(value, fre.get(value) + 1);
			}
		}
		return fre;
	}

}
